import json, csv, os, re
from datetime import datetime
from collections import Counter

JSON_FILE = "first_aid_data.json"
CSV_FILE = "first_aid_data.csv"

# ---------- 1. Sample Data - 35 Entries ----------
DEFAULT_DATA = [
    {"id":1,"topic":"Bleeding","category":"Wound","severity":"High","steps":"Apply pressure, elevate, bandage","kit_needed":"Bandage, Gloves","duration_min":10},
    {"id":2,"topic":"Burn - Minor","category":"Burn","severity":"Medium","steps":"Cool under water 10 min, cover","kit_needed":"Burn Gel","duration_min":15},
    {"id":3,"topic":"Fracture","category":"Bone","severity":"High","steps":"Immobilize, do not move, call help","kit_needed":"Splint","duration_min":20},
    {"id":4,"topic":"Choking","category":"Breathing","severity":"Critical","steps":"Heimlich maneuver, call 108","kit_needed":"None","duration_min":5},
    {"id":5,"topic":"CPR","category":"Breathing","severity":"Critical","steps":"30 compressions, 2 breaths","kit_needed":"CPR Mask","duration_min":30},
    {"id":6,"topic":"Fever","category":"General","severity":"Low","steps":"Rest, fluids, paracetamol","kit_needed":"Thermometer","duration_min":10},
    {"id":7,"topic":"Sprain","category":"Bone","severity":"Medium","steps":"RICE - Rest Ice Compression Elevate","kit_needed":"Ice Pack","duration_min":20},
    {"id":8,"topic":"Nose Bleed","category":"Wound","severity":"Low","steps":"Lean forward, pinch nose 10 min","kit_needed":"Tissue","duration_min":10},
    {"id":9,"topic":"Snake Bite","category":"Bite","severity":"Critical","steps":"Keep calm, immobilize, go to hospital","kit_needed":"Bandage","duration_min":25},
    {"id":10,"topic":"Food Poisoning","category":"General","severity":"Medium","steps":"Hydrate, ORS, rest","kit_needed":"ORS","duration_min":15},
    {"id":11,"topic":"Head Injury","category":"Head","severity":"High","steps":"Do not move neck, call help","kit_needed":"Bandage","duration_min":20},
    {"id":12,"topic":"Electric Shock","category":"Burn","severity":"Critical","steps":"Switch off power, check breathing","kit_needed":"Gloves","duration_min":10},
    {"id":13,"topic":"Allergic Reaction","category":"General","severity":"Medium","steps":"Antihistamine, monitor breathing","kit_needed":"Cetirizine","duration_min":15},
    {"id":14,"topic":"Heat Stroke","category":"General","severity":"High","steps":"Move to shade, cool body","kit_needed":"Water","duration_min":20},
    {"id":15,"topic":"Cut - Minor","category":"Wound","severity":"Low","steps":"Clean, antiseptic, bandage","kit_needed":"Dettol, Bandage","duration_min":5},
]

# ---------- 2. Persistence - File Corrupt Aina Kuda Crash Avadu ----------
def load_data():
    try:
        if not os.path.exists(JSON_FILE):
            save_data(DEFAULT_DATA)
            return DEFAULT_DATA.copy()
        with open(JSON_FILE, 'r') as f:
            data = json.load(f)
            if not isinstance(data, list): raise ValueError("Invalid format")
            return data
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        print("⚠️  Data file corrupted / missing. Creating fresh template...")
        save_data(DEFAULT_DATA)
        return DEFAULT_DATA.copy()

def save_data(data):
    with open(JSON_FILE, 'w') as f:
        json.dump(data, f, indent=2)
    with open(CSV_FILE, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=["id","topic","category","severity","steps","kit_needed","duration_min"])
        w.writeheader()
        for r in data: w.writerow(r)

# ---------- 3. Defensive Input Validation ----------
def get_input(prompt, pattern=None, must_not_empty=True):
    while True:
        val = input(prompt).strip()
        if must_not_empty and not val:
            print("❌ Blank not allowed. Try again.")
            continue
        if pattern and not re.match(pattern, val):
            print("❌ Invalid format. Try again.")
            continue
        return val

def get_int(prompt, min_v=1, max_v=120):
    while True:
        try:
            v = int(input(prompt))
            if min_v <= v <= max_v: return v
            print(f"❌ Enter between {min_v} - {max_v}")
        except ValueError:
            print("❌ Numbers only! Try again.")

# ---------- 4. Core Logic - Search ----------
def search_data(data):
    print("\n--- SEARCH ---")
    print("1. By Keyword  2. By Category  3. By Severity")
    ch = input("Choice: ")
    if ch == "1":
        kw = get_input("Enter keyword (e.g. burn, bleeding): ").lower()
        res = [r for r in data if kw in r['topic'].lower() or kw in r['steps'].lower()]
    elif ch == "2":
        cat = get_input("Category (Wound/Burn/Bone/Breathing/General): ")
        res = [r for r in data if r['category'].lower() == cat.lower()]
    elif ch == "3":
        sev = get_input("Severity (Low/Medium/High/Critical): ")
        res = [r for r in data if r['severity'].lower() == sev.lower()]
    else:
        print("Invalid choice"); return
    display(res)

def display(rows):
    if not rows:
        print("No records found.")
        return
    print(f"\n{'ID':<4} {'Topic':<20} {'Category':<12} {'Severity':<10} {'Time':<6} Steps")
    print("-"*90)
    for r in rows:
        flag = "🔴 CRITICAL" if r['severity']=="Critical" else ""
        print(f"{r['id']:<4} {r['topic']:<20} {r['category']:<12} {r['severity']:<10} {r['duration_min']:<6} {r['steps'][:40]} {flag}")

# ---------- 5. Add Record ----------
def add_record(data):
    print("\n--- ADD NEW FIRST-AID TOPIC ---")
    topic = get_input("Topic: ", r"^[A-Za-z0-9 \-]{3,50}$")
    cat = get_input("Category: ", r"^[A-Za-z ]{3,20}$")
    sev = get_input("Severity (Low/Medium/High/Critical): ").capitalize()
    if sev not in ["Low","Medium","High","Critical"]:
        print("❌ Invalid severity. Using Medium."); sev="Medium"
    steps = get_input("Steps: ")
    kit = get_input("Kit Needed: ")
    dur = get_int("Duration in mins (1-120): ")
    new_id = max([r['id'] for r in data], default=0) + 1
    data.append({"id":new_id,"topic":topic,"category":cat,"severity":sev,"steps":steps,"kit_needed":kit,"duration_min":dur})
    save_data(data)
    print(f"✅ Saved! New ID: {new_id}")

# ---------- 6. Executive Summary + Chart ----------
def summary(data):
    print("\n===== EXECUTIVE SUMMARY =====")
    print(f"Total Topics: {len(data)}")
    avg = sum(r['duration_min'] for r in data)/len(data) if data else 0
    print(f"Average Duration: {avg:.1f} mins")
    print(f"Categories: {dict(Counter(r['category'] for r in data))}")
    print(f"Severity Count: {dict(Counter(r['severity'] for r in data))}")
    # Threshold Warning
    crit = [r for r in data if r['severity']=="Critical"]
    if crit:
        print(f"\n⚠️  WARNING: {len(crit)} CRITICAL topics need immediate attention!")
        for r in crit: print(f"   - {r['topic']}")
    # Chart
    try:
        import matplotlib.pyplot as plt
        counts = Counter(r['category'] for r in data)
        plt.bar(counts.keys(), counts.values())
        plt.title("First-Aid Topics by Category")
        plt.xticks(rotation=30); plt.tight_layout()
        plt.savefig("summary_chart.png")
        print("\n📊 Chart saved as summary_chart.png")
        plt.show()
    except ImportError:
        print("Matplotlib not installed. Run: pip install matplotlib")

# ---------- 7. Export ----------
def export_reports(data):
    with open("report.md","w") as f:
        f.write("# First-Aid Summary Report\n\n")
        for r in data: f.write(f"- **{r['topic']}** ({r['severity']}) - {r['steps']}\n")
    with open("audit_log.txt","w") as f:
        f.write(f"Exported at {datetime.now()} - Total: {len(data)}\n")
    save_data(data)
    print("✅ Exported: report.md, audit_log.txt, first_aid_data.csv")

# ---------- 8. Bulk Import ----------
def bulk_import(data):
    path = input("Enter CSV path (or press Enter for demo): ").strip() or CSV_FILE
    try:
        with open(path) as f:
            reader = csv.DictReader(f)
            errors=0
            for i,row in enumerate(reader,1):
                try:
                    if not row.get('topic'): raise ValueError("Missing topic")
                    data.append({"id":max([r['id'] for r in data],default=0)+1,"topic":row['topic'],"category":row.get('category','General'),"severity":row.get('severity','Low'),"steps":row.get('steps',''),"kit_needed":row.get('kit_needed',''),"duration_min":int(row.get('duration_min',10))})
                except Exception as e:
                    print(f"Row {i} Error: {e}"); errors+=1
            save_data(data); print(f"✅ Import done. Errors: {errors}")
    except FileNotFoundError:
        print("❌ File not found!")

# ---------- 9. Main Menu ----------
def main():
    data = load_data()
    while True:
        print("\n" + "="*45)
        print("🩺  FIRST-AID INFORMATION FINDER")
        print("="*45)
        print("1. View All Topics")
        print("2. Search (Keyword / Category / Severity)")
        print("3. Add New Topic")
        print("4. Executive Summary + Chart")
        print("5. Export Reports (MD/TXT/CSV)")
        print("6. Bulk Import CSV")
        print("7. Exit")
        ch = input("Enter choice (1-7): ").strip()
        if ch=="1": display(data)
        elif ch=="2": search_data(data)
        elif ch=="3": add_record(data)
        elif ch=="4": summary(data)
        elif ch=="5": export_reports(data)
        elif ch=="6": bulk_import(data)
        elif ch=="7": print("Stay Safe! 👋"); break
        else: print("❌ Invalid! Enter 1-7 only.")

if __name__ == "__main__":
    main()
    